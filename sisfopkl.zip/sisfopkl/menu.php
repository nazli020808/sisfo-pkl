<nav>
    <a href="crud/home.php" target="contentFrame">Home</a>
    <a href="crud/jurnal.php" target="contentFrame">Jurnal</a>
    <a href="crud/absen.php" target="contentFrame">Absen</a>
    <a href="crud/konsultasi.php" target="contentFrame">Konsultasi</a>
</nav>
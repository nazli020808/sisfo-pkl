<!DOCTYPE html>
<html lang="en">
 <head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Sisfo PKL SMK N 2 Padang Panjang</title>
 <link rel="stylesheet" href="styles.css">
<style>
 body {
 font-family: Arial, sans-serif;


 margin: 0;
 padding: 0;
 background-color: #f4f4f4;
 }
 header, footer {
 background-color:#537D5D;
 color: white;
 text-align: center;
 padding: 10px 0;
 }
 nav {
 background-color: #9EBC8A;
 padding: 10px;
 text-align: center;
 }
 nav a {
 color: white;
 margin: 0 15px;
 text-decoration: none;
 }
 nav a:hover {
 text-decoration: underline;
 }
 #content {
 padding: 15px0px;
 }
 iframe {
 width: 100%;
 height: 400px;
 border: none;
 }
</style>
 </head>
 <body>

 <!-- Include Header -->
 <?php include 'header.php'; ?>

 <!-- Include Menu -->
 <?php include 'menu.php'; ?>

 <!-- Main Content with Iframe -->
 <div id="content">
 <iframe name="contentFrame" src="crud/home.php"></iframe>
 </div>

 <!-- Include Footer -->
 <?php include 'footer.php'; ?>

 </body>
 </html>
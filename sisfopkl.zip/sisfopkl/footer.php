<footer>
 <p>SMEKDA Coding - Design By M.Nazli Xll RPL 3</p>
</footer>
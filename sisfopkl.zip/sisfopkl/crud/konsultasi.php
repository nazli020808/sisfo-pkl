<!DOCTYPE html>
 <html lang="en">
 <head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Halaman Konsultasi</title>
  <link rel="stylesheet" href="styles.css">
</head>
 <body>
 
    <div class="chat-container">
        <h2>Konsultasi Chat</h2>
    <div class="chat-box" id="chatBox">
    </div>

    <input type="text" id="chatInput" class="chat-input" placeholder="Tulis pesan...">
        <button onclick="sendMessage()">Kirim</button>
    </div>

    <script>
        function sendMessage() {
        const chatInput = document.getElementById('chatInput');
        const chatBox = document.getElementById('chatBox');
        const message = chatInput.value.trim();

    if (message) {
        const userMessage = document.createElement('div');
        userMessage.className = 'message user';
        userMessage.innerText = message;
 chatBox.appendChild(userMessage);


 const adminMessage = document.createElement('div');
 adminMessage.className = 'message admin';
 adminMessage.innerText = 'Admin: Terima kasih, pesan Anda telah diterima.';
 chatBox.appendChild(adminMessage);


chatBox.scrollTop = chatBox.scrollHeight;


 chatInput.value = '';
 }
 }
 </script>
 </body>
 </html>
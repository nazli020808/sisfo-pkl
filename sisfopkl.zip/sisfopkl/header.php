<header>
 <h1>Sistem Informasi PKL SMK N 2 Padang Panjang</h1>
 <p>Siswa - Halaman Untuk Isi Jurnal dan Absen Serta Konsultasi
dengan Pembimbing</p>
</header>